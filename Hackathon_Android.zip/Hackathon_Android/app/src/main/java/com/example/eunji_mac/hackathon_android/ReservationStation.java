package com.example.eunji_mac.hackathon_android;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ReservationStation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation_station);
    }
}
